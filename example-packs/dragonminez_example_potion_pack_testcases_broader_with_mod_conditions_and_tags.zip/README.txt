DragonMineZ potion pack broader test cases.

Covers:
- Four DMZ custom effects
- Vanilla effects
- Partial family overrides
- Disable by family/tier/duration/combination with minimal fields
- Mod-loaded checks via required_mods and load_condition
- Same-id mod-gated override fallback
- effect_tags / group-based effect selection and fallback
